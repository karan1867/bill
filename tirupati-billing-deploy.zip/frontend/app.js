
const API = (typeof API_BASE !== 'undefined' && API_BASE) ? API_BASE : (localStorage.getItem('apiBase') || 'http://localhost:3000');
const logoURL = localStorage.getItem('shopLogo') || '';
if (logoURL) { const el=document.getElementById('shopLogo'); if (el) el.src = logoURL; }

const tbody = document.querySelector('#items tbody');
let installPromptEvent = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  installPromptEvent = e;
  document.getElementById('installBtn').style.display = 'inline-flex';
});
document.getElementById('installBtn')?.addEventListener('click', async () => {
  if (!installPromptEvent) return;
  installPromptEvent.prompt();
  await installPromptEvent.userChoice;
  installPromptEvent = null;
  document.getElementById('installBtn').style.display = 'none';
});

function updateOfflineTag(){
  const el = document.getElementById('offlineTag');
  if (el) el.style.display = navigator.onLine ? 'none' : 'inline-block';
}
window.addEventListener('online', updateOfflineTag);
window.addEventListener('offline', updateOfflineTag);
updateOfflineTag();

document.getElementById('billDate').valueAsDate = new Date();
document.getElementById('billNo').value = `TC-${String(Math.floor(Math.random()*9000)+1000)}`;

function addRow(){
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input placeholder="Item name"></td>
    <td><input type="number" value="1" min="1" inputmode="decimal" oninput="recalc()"></td>
    <td><input type="number" value="0" min="0" inputmode="decimal" oninput="recalc()"></td>
    <td><input type="number" value="0" min="0" inputmode="decimal" oninput="recalc()"></td>
    <td><input type="number" value="0" min="0" inputmode="decimal" oninput="recalc()"></td>
    <td class="lt">0.00</td>
    <td><button onclick="this.closest('tr').remove(); recalc();">X</button></td>`;
  document.querySelector('#items tbody').appendChild(tr);
  recalc();
}
window.addRow = addRow;

function recalc(){
  const tbody = document.querySelector('#items tbody');
  let subtotal=0, discAmt=0, taxAmt=0, grand=0;
  [...tbody.children].forEach(tr => {
    const qty  = parseFloat(tr.children[1].querySelector('input').value) || 0;
    const rate = parseFloat(tr.children[2].querySelector('input').value) || 0;
    const d    = parseFloat(tr.children[3].querySelector('input').value) || 0;
    const t    = parseFloat(tr.children[4].querySelector('input').value) || 0;
    let line = qty*rate;
    const ld = line*(d/100); line -= ld; discAmt += ld;
    const lt = line*(t/100); line += lt; taxAmt += lt;
    tr.querySelector('.lt').textContent = line.toFixed(2);
    subtotal += qty*rate;
    grand += line;
  });
  document.getElementById('subTotal').textContent = subtotal.toFixed(2);
  document.getElementById('discAmt').textContent = discAmt.toFixed(2);
  document.getElementById('taxAmt').textContent  = taxAmt.toFixed(2);
  document.getElementById('grandTotal').textContent = grand.toFixed(2);
}
window.recalc = recalc;

async function saveInvoice(){
  const tbody = document.querySelector('#items tbody');
  const items = [...tbody.children].map(tr => ({
    item_name: tr.children[0].querySelector('input').value.trim(),
    qty: parseFloat(tr.children[1].querySelector('input').value)||0,
    rate: parseFloat(tr.children[2].querySelector('input').value)||0,
    discount: parseFloat(tr.children[3].querySelector('input').value)||0,
    tax: parseFloat(tr.children[4].querySelector('input').value)||0,
    line_total: parseFloat(tr.querySelector('.lt').textContent)||0
  })).filter(i=>i.item_name);

  const payload = {
    bill_no: document.getElementById('billNo').value,
    date: document.getElementById('billDate').value,
    customer_name: document.getElementById('custName').value,
    customer_mobile: document.getElementById('custMobile').value,
    subtotal: parseFloat(document.getElementById('subTotal').textContent)||0,
    discount: parseFloat(document.getElementById('discAmt').textContent)||0,
    tax: parseFloat(document.getElementById('taxAmt').textContent)||0,
    grand_total: parseFloat(document.getElementById('grandTotal').textContent)||0,
    items
  };

  try{
    const r = await fetch(`${API}/api/invoices`,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    if (!r.ok) throw new Error('server');
    alert('Invoice saved ✅');
    tbody.innerHTML=''; addRow(); listInvoices();
  }catch(e){
    const pending = JSON.parse(localStorage.getItem('pendingInvoices')||'[]');
    pending.push(payload);
    localStorage.setItem('pendingInvoices', JSON.stringify(pending));
    alert('Saved offline. Will sync later.');
    tbody.innerHTML=''; addRow(); listInvoices();
  }
}
window.saveInvoice = saveInvoice;

async function syncPending(){
  const pending = JSON.parse(localStorage.getItem('pendingInvoices')||'[]');
  if (!pending.length){ alert('No pending invoices.'); return; }
  const ok = [];
  for (const p of pending){
    try{
      const r = await fetch(`${API}/api/invoices`,{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(p)});
      if (r.ok) ok.push(p);
    }catch(e){ }
  }
  if (ok.length){
    const rest = pending.filter(p => !ok.includes(p));
    localStorage.setItem('pendingInvoices', JSON.stringify(rest));
    alert(`Synced ${ok.length} invoice(s)`);
  } else {
    alert('Could not sync. Check server.');
  }
}
window.syncPending = syncPending;

async function listInvoices(){
  const box = document.getElementById('invoiceList');
  try{
    const r = await fetch(`${API}/api/invoices`);
    const list = await r.json();
    box.innerHTML = list.slice(0,20).map(inv => `#${inv.bill_no} • ₹${inv.grand_total} • ${inv.date}`).join('<br>');
  }catch(e){
    box.innerHTML = '<em>Offline: cannot load server invoices.</em>';
  }
}
listInvoices();

if ('serviceWorker' in navigator){
  navigator.serviceWorker.register('sw.js');
}
