// Set your live backend API here or via Settings page
// Example: 'https://tirupati-api.onrender.com'
const API_BASE = '';
