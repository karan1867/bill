const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'billing.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    rate REAL NOT NULL,
    tax REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_no TEXT NOT NULL,
    date TEXT NOT NULL,
    customer_name TEXT,
    customer_mobile TEXT,
    subtotal REAL,
    discount REAL,
    tax REAL,
    grand_total REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER,
    item_name TEXT,
    qty REAL,
    rate REAL,
    discount REAL,
    tax REAL,
    line_total REAL,
    FOREIGN KEY(invoice_id) REFERENCES invoices(id)
  )`);
});

app.use(cors());
app.use(bodyParser.json({limit:'2mb'}));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.get('/api/products', (req, res) => {
  db.all("SELECT * FROM products ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/api/products', (req, res) => {
  const { name, rate, tax=0 } = req.body || {};
  if (!name || rate==null) return res.status(400).json({error: "name and rate required"});
  db.run("INSERT INTO products (name, rate, tax) VALUES (?, ?, ?)", [name, rate, tax], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({ id: this.lastID, name, rate, tax });
  });
});

app.get('/api/invoices', (req, res) => {
  db.all("SELECT * FROM invoices ORDER BY id DESC LIMIT 200", [], (err, invoices) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(invoices);
  });
});

app.get('/api/invoices/:id', (req, res) => {
  const id = req.params.id;
  db.get("SELECT * FROM invoices WHERE id=?", [id], (err, invoice) => {
    if (err) return res.status(500).json({error: err.message});
    if (!invoice) return res.status(404).json({error: "not found"});
    db.all("SELECT * FROM invoice_items WHERE invoice_id=?", [id], (err2, items) => {
      if (err2) return res.status(500).json({error: err2.message});
      res.json({ invoice, items });
    });
  });
});

app.post('/api/invoices', (req, res) => {
  const { bill_no, date, customer_name, customer_mobile, subtotal=0, discount=0, tax=0, grand_total=0, items=[] } = req.body || {};
  if (!bill_no || !date) return res.status(400).json({error: "bill_no and date required"});
  db.run(`INSERT INTO invoices (bill_no, date, customer_name, customer_mobile, subtotal, discount, tax, grand_total) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [bill_no, date, customer_name||'', customer_mobile||'', subtotal, discount, tax, grand_total],
    function(err){
      if (err) return res.status(500).json({error: err.message});
      const invoice_id = this.lastID;
      const stmt = db.prepare(`INSERT INTO invoice_items (invoice_id, item_name, qty, rate, discount, tax, line_total) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)`);
      for (const it of items) {
        stmt.run([invoice_id, it.item_name, it.qty, it.rate, it.discount||0, it.tax||0, it.line_total||0]);
      }
      stmt.finalize((err2)=>{
        if (err2) return res.status(500).json({error: err2.message});
        res.json({ id: invoice_id, bill_no });
      });
    });
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
