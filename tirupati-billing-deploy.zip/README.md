# Tirupati Billing • Deployment Guide

This package is ready for hosting the **frontend (PWA)** and **backend API (Node + SQLite)** separately.

## 1) Deploy Backend (API + SQLite)
### Option A: Render (simple)
1. Create a free Render account and connect your repo, or click **New > Web Service** and upload the `backend/` folder.
2. Set **Root Directory** = `backend`
3. Build Command: `npm install`
4. Start Command: `node server.js`
5. After deploy, you will get a URL like `https://tirupati-api.onrender.com`

> ⚠️ Note: Free tiers on some hosts use **ephemeral disks**. SQLite file may reset on redeploys or restarts. For persistence, attach a **paid disk/volume** on your host, or switch to a managed DB later.

### Option B: Railway
1. Create a Railway project, **New > Deploy from Repo** (or Upload), root `backend/`.
2. Railway auto-detects Node. Set Start command `node server.js` if needed.
3. Set a **volume** for persistence if your plan allows.

## 2) Deploy Frontend (PWA)
### Option A: Vercel
- Push these files to a Git repo and **Import Project** into Vercel.
- It uses `vercel.json` to serve `frontend/` statically.

### Option B: Netlify
- Drag & drop the `frontend/` folder in Netlify deploy dashboard.
- Or connect your repo and set **Publish Directory** to `frontend`.

## 3) Connect Frontend to Backend
After backend URL is live (e.g. `https://tirupati-api.onrender.com`):

**Method 1 (Settings page):**
- Open your site `/settings.html` and set **API Base URL** to your backend URL. Save.

**Method 2 (config file):**
- Edit `frontend/config.js` and set:
```js
const API_BASE = 'https://tirupati-api.onrender.com';
```
Re-deploy frontend.

## 4) Use
- Open the site on mobile/desktop, **Add to Home Screen** to install.
- Create bills, save online (or offline then **Sync Pending** later).

## 5) Local Development
Backend:
```bash
cd backend
npm install
npm start
```
Frontend:
- Just open `frontend/index.html` in your browser.
- Settings → API Base URL: `http://localhost:3000`

## Notes
- Shop header (Marathi): 🛍️ तिरुपती कलेक्शन — Ashoknagar • 7620506962
- You can change the logo on `/settings.html` (paste image URL).
- Later upgrades: products master, print/PDF invoice, GST, cloud DB.

— Enjoy! 🙌
